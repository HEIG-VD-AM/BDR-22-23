SET search_path = pagila;

-- BEGIN Exercice 01
SELECT
    C.customer_id,
    C.last_name AS nom,
    C.email
FROM customer C
WHERE
    C.store_id = 1
    AND C.first_name = 'PHYLLIS'
ORDER BY customer_id DESC;
-- END Exercice 01


-- BEGIN Exercice 02
SELECT
    F.title AS titre,
    F.release_year AS annee_sortie
FROM
    film F
WHERE
    F.rating = 'R'
    AND F.length < 60
    AND F.replacement_cost = 12.99
ORDER BY F.title;
-- END Exercice 02


-- BEGIN Exercice 03
SELECT
    country,
    city,
    postal_code
FROM
    city CT
    JOIN address A ON A.city_id = CT.city_id
    JOIN country CO ON CO.country_id = CT.country_id
WHERE
    country = 'France'
    OR (CT.country_id >= 63
    AND CT.country_id <= 67)
ORDER BY
    country,
    city,
    postal_code;
-- END Exercice 03


-- BEGIN Exercice 04
SELECT
    C.customer_id,
    C.first_name AS prenom,
    C.last_name AS nom
FROM
    customer C
    JOIN address A ON A.address_id = C.address_id
WHERE
    C.active = true
    AND C.store_id = 1
    AND A.city_id = 171
ORDER BY
    c.first_name;
-- END Exercice 04


-- BEGIN Exercice 05
SELECT DISTINCT
        C1.first_name AS prenom_1,
        C1.last_name AS nom_1,
        C2.first_name AS prenom_2,
        C2.last_name AS nom_2
FROM customer C1
    JOIN rental R1 ON C1.customer_id = R1.customer_id
    JOIN inventory I1 ON R1.inventory_id = I1.inventory_id
    JOIN rental R2 ON I1.inventory_id = R2.inventory_id
    JOIN inventory I2 ON R2.inventory_id = I2.inventory_id
    JOIN customer C2 ON R2.customer_id = C2.customer_id
WHERE C1.customer_id < C2.customer_id;
-- END Exercice 05


-- BEGIN Exercice 06
SELECT
    last_name AS nom,
    first_name AS prenom
FROM actor A
WHERE A.actor_id IN (
     SELECT
        FA.actor_id
     FROM film_actor FA
     WHERE A.actor_id = FA.actor_id
       AND FA.film_id IN (
           SELECT
                FC.film_id
           FROM film_category FC
           WHERE FC.category_id IN (
               SELECT
                  C.category_id
               FROM category C
               WHERE C.name = 'Horror'
               )
         )
     ) AND A.first_name LIKE 'K%' OR A.last_name LIKE 'D%';
-- END Exercice 06


-- BEGIN Exercice 07a
SELECT
    F.film_id AS id, 
    F.title AS titre, 
    F.rental_rate/F.rental_duration AS prix_de_location_par_jour
FROM film F
WHERE F.rental_rate/F.rental_duration <= 1.00
EXCEPT
SELECT 
    F.film_id AS id, 
    F.title AS titre, 
    F.rental_rate/F.rental_duration AS prix_de_location_par_jour
FROM film F
    JOIN inventory I ON I.film_id = F.film_id
    JOIN  rental R ON I.inventory_id = R.inventory_id;
-- END Exercice 07a

-- BEGIN Exercice 07b
SELECT
    F.film_id AS id,
    F.title as titre,
    F.rental_rate / F.rental_duration as prix_de_location_par_jour
FROM
    film F
WHERE (F.rental_rate / F.rental_duration) <= 1.0
INTERSECT
SELECT
    F.film_id AS id,
    F.title as titre,
    F.rental_rate / F.rental_duration as prix_de_location_par_jour
FROM
    film F
WHERE f.film_id NOT IN (
        SELECT
            I.film_id
        FROM inventory I
    );
-- END Exercice 07b


-- BEGIN Exercice 08a
SELECT
    C.customer_id as id,
    C.last_name as nom,
    C.first_name as prenom
FROM
    customer C
    JOIN address A on C.address_id = A.address_id
    JOIN city CT on A.city_id = CT.city_id
    WHERE CT.country_id = (SELECT C.country_id FROM country C WHERE C.country = 'Spain' ) AND EXISTS (
        SELECT R.return_date
        FROM rental R
        WHERE R.customer_id = C.customer_id and R.return_date IS NULL
        )
    ORDER BY C.last_name;
-- END Exercice 08a

-- BEGIN Exercice 08b
SELECT
    C.customer_id as id,
    C.last_name as nom,
    C.first_name as prenom
FROM
    customer C
    JOIN address A on C.address_id = A.address_id
    JOIN city CT on A.city_id = CT.city_id
    JOIN rental R on R.customer_id = C.customer_id AND R.return_date IS NULL
    WHERE CT.country_id IN (
        SELECT
            CO.country_id
        FROM country CO
        WHERE CO.country_id = (SELECT C.country_id FROM country C WHERE C.country = 'Spain' ))
    ORDER BY C.last_name;
-- END Exercice 08b

-- BEGIN Exercice 08c
SELECT
    C.customer_id as id,
    C.last_name as nom,
    C.first_name as prenom
FROM
    customer C
    JOIN address A on C.address_id = A.address_id
    JOIN city CT on A.city_id = CT.city_id
    JOIN rental R on R.customer_id = C.customer_id AND R.return_date IS NULL
    WHERE CT.country_id = (SELECT C.country_id FROM country C WHERE C.country = 'Spain' )
    ORDER BY C.last_name;
-- END Exercice 08c


-- BEGIN Exercice 09 (Bonus)
SELECT DISTINCT
    C.customer_id,
    C.first_name as prenom,
    C.last_name as nom
FROM customer C
    JOIN rental R ON R.customer_id = C.customer_id
    JOIN inventory I on R.inventory_id = I.inventory_id
WHERE I.film_id IN (
    SELECT DISTINCT
        FA.film_id
    FROM film_actor FA
        JOIN actor A ON FA.actor_id = A.actor_id
    WHERE A.first_name = 'EMILY' AND A.last_name = 'DEE')
GROUP BY (C.customer_id, C.first_name, C.last_name)
HAVING COUNT(DISTINCT I.film_id) = (
        SELECT COUNT(*)
        FROM film_actor FA
            JOIN actor A ON FA.actor_id = A.actor_id
        WHERE A.first_name = 'EMILY' AND A.last_name = 'DEE');
-- END Exercice 09 (Bonus)


-- BEGIN Exercice 10
SELECT F.title AS titre,
       COUNT(A.actor_id) AS nb_acteurs
FROM
    film F
    JOIN film_category FC ON F.film_id = FC.film_id
    JOIN category C ON C.category_id = FC.category_id
    JOIN film_actor FA on F.film_id = FA.film_id
    JOIN actor A on FA.actor_id = A.actor_id
WHERE C.name = 'Drama'
GROUP BY F.film_id
HAVING COUNT(A.actor_id) < 5
ORDER BY COUNT(A.actor_id) DESC;
-- END Exercice 10


-- BEGIN Exercice 11
SELECT C.category_id AS id,
       C.name AS nom,
       COUNT(FC.film_id) AS nb_films
FROM category C
    JOIN film_category FC ON C.category_id = FC.category_id
GROUP BY C.category_id
HAVING COUNT(FC.film_id) > 65
ORDER BY COUNT(FC.film_id);
-- END Exercice 11


-- BEGIN Exercice 12
SELECT
    F.film_id AS id,
    F.title AS titre,
    F.length AS duree
FROM film F
WHERE F.length = (
    SELECT
        MIN(F.length)
    FROM film F
    );
-- END Exercice 12


-- BEGIN Exercice 13a
SELECT DISTINCT
    F.film_id AS id,
    F.title AS titre
FROM film F
    JOIN film_actor FA ON F.film_id = FA.film_id
WHERE FA.actor_id IN (
        SELECT FA.actor_id
        FROM film_actor FA
        GROUP BY (FA.actor_id)
        HAVING COUNT(FA.actor_id) > 40
    );
-- END Exercice 13a


-- BEGIN Exercice 13b
SELECT DISTINCT
    F.film_id AS id,
    F.title AS titre
FROM film F
    JOIN film_actor FA ON FA.film_id = F.film_id
    JOIN (
        SELECT
            FA.actor_id
        FROM film_actor FA
        GROUP BY (FA.actor_id)
        HAVING COUNT(FA.actor_id) > 40) AIT ON AIT.actor_id = FA.actor_id;
-- END Exercice 13b


-- BEGIN Exercice 14
SELECT
    (SUM(F.length) / 60) / 8 AS nb_jours
FROM film F;
-- END Exercice 14


-- BEGIN Exercice 15
SELECT *
FROM (
    SELECT
        C.customer_id AS id,
        C.last_name AS nom,
        C.email,
        CO.country AS pays,
        COUNT(R.rental_id) as nb_locations,
        SUM(P.amount) as depense_total,
        AVG(P.amount) as depense_moyenne
    FROM customer C
        JOIN rental R ON R.customer_id = C.customer_id
        JOIN address A ON A.address_id = C.address_id
        JOIN city CT ON CT.city_id = A.city_id
        JOIN country CO ON CT.country_id = CO.country_id
        JOIN payment p on C.customer_id = p.customer_id AND p.rental_id = R.rental_id
    WHERE CO.country = 'Switzerland'
        OR CO.country = 'France'
        OR CO.country = 'Germany'
    GROUP BY (C.customer_id, C.last_name, C.email, CO.country)) C
WHERE C.depense_moyenne > 3.0
ORDER BY C.pays, C.nom;
-- END Exercice 15


-- BEGIN Exercice 16a
SELECT 
    COUNT(*)
FROM payment P
WHERE P.amount <= 9;
-- 15678
-- END Exercice 16a

-- BEGIN Exercice 16b
DELETE
FROM payment P
WHERE P.amount <= 9;
-- END Exercice 16b

-- BEGIN Exercice 16c
SELECT 
    COUNT(*)
FROM payment P
WHERE P.amount <= 9;
-- 0
-- END Exercice 16c


-- BEGIN Exercice 17
UPDATE 
    payment
SET
    amount = amount * 1.5, payment_date = CURRENT_DATE
WHERE amount >= 4;
-- END Exercice 17


-- BEGIN Exercice 18
INSERT INTO
    city(city, country_id, last_update)
VALUES
    ('Nyon', (SELECT C.country_id FROM country C WHERE C.country = 'Switzerland'), CURRENT_DATE);
INSERT INTO
    address(address, address2, district, city_id, postal_code, phone, last_update)
VALUES
    ('Rue du Centre', NULL, 'Vaud', (SELECT C.city_id FROM city C WHERE C.city = 'Nyon'), '1260', '0213600000', CURRENT_DATE);
INSERT INTO
    customer(store_id, first_name, last_name, email, address_id, active, create_date, last_update)
VALUES
    (1, 'Guillaume', 'Ransome', 'gr@bluewin.ch', (SELECT A.address_id FROM address A WHERE A.address  = 'Rue du Centre' AND A.district = 'Vaud' AND A.postal_code = '1260' AND A.phone = '0213600000') , true, CURRENT_DATE, CURRENT_DATE);
-- END Exercice 18

-- BEGIN Exercice 18d
SELECT *
FROM customer C
    JOIN address A on C.address_id = A.address_id
    JOIN city CI on A.city_id = CI.city_id
    JOIN country CO on CI.country_id = CO.country_id
WHERE C.first_name = 'Guillaume' AND C.last_name = 'Ransome';
-- END Exercice 18d