SET search_path = pagila;

--
-- Triggers
---------------------------

-- Exercice 01
DROP TRIGGER IF EXISTS payment_update_trigger ON payment;
DROP FUNCTION IF EXISTS payment_update();
CREATE FUNCTION payment_update()
RETURNS TRIGGER AS
$payment_update_trigger$
    BEGIN
        NEW.amount = NEW.amount * 1.08;
        NEW.payment_date = current_timestamp;
        RETURN NEW;
    END;
$payment_update_trigger$
LANGUAGE plpgsql;

CREATE TRIGGER payment_update_trigger BEFORE INSERT
ON payment
FOR EACH ROW
EXECUTE FUNCTION payment_update();

-- Insertion d'un nouveau paiement
INSERT INTO
    payment (customer_id, staff_id, rental_id, amount, payment_date)
    VALUES  (1, 1, 1, 100, '2007-02-15')
    RETURNING *;
-- END Exercice 01

-- Exercice 02
CREATE TABLE staff_creation_log (
    username varchar(16),
    when_created timestamp with time zone
);

CREATE FUNCTION staff_log_fill()
RETURNS TRIGGER AS
$staff_creation_trigger$
    BEGIN
        INSERT INTO
            staff_creation_log (username, when_created)
            VALUES (NEW.username, current_timestamp);
        RETURN NEW;
    END;
$staff_creation_trigger$
LANGUAGE plpgsql;

CREATE TRIGGER staff_creation_trigger BEFORE INSERT
ON staff
FOR EACH ROW
EXECUTE FUNCTION staff_log_fill();

INSERT INTO
    staff  (first_name, last_name, address_id, email, store_id, active, username, password, last_update)
    VALUES ('John', 'Smith', 1, 'JohnSmith@mail.ch', 1, true, 'JohnSmith', '1234', '2006-02-15 09:45:30');

-- Sélection de la dernière insertion dans la table staff_creation_log
SELECT *
FROM staff_creation_log
ORDER BY when_created
DESC LIMIT 1;

-- END Exercice 02

-- Exercice 03
CREATE FUNCTION staff_update()
RETURNS TRIGGER AS
$staff_update_trigger$
    BEGIN
        NEW.email = NEW.first_name || '.' || NEW.last_name || '@sakilastaff.com';
        RETURN NEW;
    END;
$staff_update_trigger$
LANGUAGE plpgsql;

CREATE TRIGGER staff_update_insert_trigger BEFORE INSERT
ON staff
FOR EACH ROW
EXECUTE FUNCTION staff_update();

CREATE TRIGGER staff_update_update_trigger BEFORE UPDATE
ON staff
FOR EACH ROW
EXECUTE FUNCTION staff_update();

-- insert new staff
INSERT INTO
    staff  (first_name, last_name, address_id, email, store_id, active, username, password, last_update)
    VALUES ('Gérard', 'Smith', 1, 'GerardSmith@mail.ch', 1, true, 'GérardSmith', '4321', '2006-02-15 09:45:30')
    RETURNING *;

-- END Exercice 03

--
-- Vues
---------------------------

-- Exercice 04
CREATE VIEW staff_email AS
    SELECT S.first_name,
           S.last_name,
           A.phone,
           A.address,
           A.postal_code,
           C.city
    FROM staff S
        JOIN address A on S.address_id = A.address_id
        JOIN city C on A.city_id = C.city_id;

-- Contrôle de la vue (pas chez l'ophtalmologue)
SELECT *
FROM staff_email;

-- Réponse à la question : Cette vue n'est pas modifiable, car elle ne cible pas qu'une seule table.

-- END Exercice 04

-- Exercice 05
CREATE VIEW late_rentals AS
    SELECT C.customer_id,
           C.email,
           F.title,
           EXTRACT(DAY FROM (current_date - R.rental_date - F.rental_duration)) AS days
    FROM customer C
        JOIN rental R ON C.customer_id = R.customer_id
        JOIN inventory I ON R.inventory_id = I.inventory_id
        JOIN film F ON I.film_id = F.film_id
    WHERE R.return_date IS NULL
        AND R.rental_date + F.rental_duration * INTERVAL '1 day' < current_date;

-- Contrôle de la vue
SELECT *
FROM late_rentals;

-- END Exercice 05

-- Exercice 06

CREATE VIEW late_rentals_3days AS
    SELECT LR.customer_id,
           LR.email,
           LR.title,
           LR.days
    FROM late_rentals LR
    WHERE days > 3;

SELECT *
FROM late_rentals_3days;

-- END Exercice 06

-- Exercice 07

CREATE VIEW rentals_per_client AS
    SELECT R.customer_id,
           C.first_name,
           C.last_name,
           COUNT(*) AS nb_locations
    FROM rental R
    JOIN customer C on R.customer_id = C.customer_id
    GROUP BY R.customer_id, C.first_name, C.last_name;

SELECT *
FROM rentals_per_client
ORDER BY nb_locations DESC
LIMIT 20;

-- END Exercice 07

-- Exercice 08

CREATE VIEW rentals_per_day AS
    SELECT date_trunc('day', R.rental_date) AS rental_date,
           COUNT(*) AS nb_rentals
    FROM rental R
    GROUP BY date_trunc('day', R.rental_date);

SELECT *
FROM rentals_per_day
WHERE rental_date = '2005-08-01';

-- END Exercice 08

--
-- Procédures / Fonctions
---------------------------

-- Exercice 09
CREATE FUNCTION nb_films_per_store(id_store INT)
    RETURNS INT
    LANGUAGE plpgsql
    AS
    $nb_films_per_store$
    DECLARE
        count_film INT;
    BEGIN
        SELECT COUNT(*) AS nb_films
        INTO count_film
        FROM inventory I
        WHERE I.store_id = id_store
        GROUP BY I.store_id;
        RETURN count_film;
    END;
    $nb_films_per_store$;

-- Sélection des films avec la fonction que l'on a créé
SELECT nb_films_per_store(1);
SELECT nb_films_per_store(2);

-- Vérification avec le contenu de la table
SELECT COUNT(*) FROM inventory WHERE store_id = 1;
SELECT COUNT(*) FROM inventory WHERE store_id = 2;

-- END Exercice 09

-- Exercice 10

SELECT  *
FROM film;

CREATE PROCEDURE update_film_last_update()
    LANGUAGE plpgsql
    AS
    $update_film_last_update$
    BEGIN
        UPDATE film
        SET last_update = current_timestamp;
    END;
    $update_film_last_update$;

call update_film_last_update();

SELECT  *
FROM film;
-- END Exercice 10
